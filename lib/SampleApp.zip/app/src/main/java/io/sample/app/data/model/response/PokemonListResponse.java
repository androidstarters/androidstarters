package io.sample.app.data.model.response;

import java.util.List;

public class PokemonListResponse {
    public List<NamedResource> results;
}
