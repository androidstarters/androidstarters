package io.sample.app.data.model.response;

import com.google.gson.annotations.SerializedName;

public class Sprites {
    @SerializedName("front_default")
    public String frontDefault;
}
