package io.sample.app.data.model.response;

public class NamedResource {
    public String name;
    public String url;
}
